create
  definer = root@`192.168.2.48` procedure inverse_amr_device_path() comment '删除`seed_amr_device_path`存储过程生成的数据，即`amr_device_path`.`RELATIVE_PHASE` = ''xx''的条目'
BEGIN
		DELETE FROM amr_device_path
		WHERE RELATIVE_PHASE = 'xx';
	END;

