create definer = root@localhost view view_device as
select `a`.`ID`                                           AS `ID`,
       `a`.`DEVICE_NUM`                                   AS `DEVICE_NUM`,
       if(`pp`.`ID`, `pp`.`DEVICE_NUM`, `p`.`DEVICE_NUM`) AS `CON_CODE`
from ((`smartami`.`am_device` `a` left join `smartami`.`am_device` `p` on ((`a`.`PARENT_ID` = `p`.`ID`)))
       left join `smartami`.`am_device` `pp` on ((`p`.`PARENT_ID` = `pp`.`ID`)));

