create
  definer = root@`192.168.2.48` procedure p_while_do()
begin  
    declare i int;  
        set i = 1;  
        while i <= 10 do  
            INSERT INTO sys_lang_package_copy1 VALUES ('Z', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL);
            set i = i + 1;  
        end while;  
end;

