create
  definer = root@`192.168.2.48` procedure tool_getRandDatetime(OUT rvl datetime, IN start datetime, IN end datetime) comment '用于获取start和end之间的随机日期时间'
BEGIN
		SELECT
			FROM_UNIXTIME(UNIX_TIMESTAMP(start) + RAND() * (UNIX_TIMESTAMP(end) - UNIX_TIMESTAMP(start)),
			              '%Y-%m-%d %H:%i:%s')
		INTO rvl;
	END;

