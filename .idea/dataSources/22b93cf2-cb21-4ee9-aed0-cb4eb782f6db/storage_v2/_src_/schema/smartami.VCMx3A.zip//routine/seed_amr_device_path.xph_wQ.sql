create
  definer = root@`192.168.2.48` procedure seed_amr_device_path(IN itemAmount int) comment '随机生成数据，关联的表有`am_device`，涉及`am_device`.`TYPE`。生成的虚拟数据`amr_device_path`.`RELATIVE_PHASE` = ''xx''，可用inverse_amr_device_path删除.'
louv: BEGIN

		DECLARE i INT DEFAULT 0;

		-- 参数判断

		SELECT
			COUNT(*)
		INTO @conAmount
		FROM am_device AS a
		WHERE a.TYPE = '1';

		SELECT
			COUNT(*)
		INTO @meterAmount
		FROM am_device AS a
		WHERE a.TYPE = '0';

		IF itemAmount <= 0 OR itemAmount > 1000
		THEN
			SELECT
				'First Param Error: 0 <= itemAmount <= 1000';
			LEAVE louv;
		ELSEIF @conAmount = 0
			THEN
				SELECT
					'There exists no CONCENTRATOR in `am_device`';
				LEAVE louv;
		ELSEIF @meterAmount < itemAmount
			THEN
				SELECT
					CONCAT('There exists not enough meters in `am_device`: **', @meterAmount, '** only');
				LEAVE louv;
		ELSE

			-- 1. 插入基本数据
			BEGIN
				DECLARE phase INT;
				DECLARE randPhase FLOAT;

				generate: LOOP

					SELECT
						a.DEVICE_NUM
					INTO @conNum
					FROM am_device AS a
					WHERE a.TYPE = '1'
					ORDER BY RAND()
					LIMIT 1;

					SET randPhase = RAND();

					IF randPhase < 0.333
					THEN
						SET phase = 1;
					ELSEIF randPhase < 0.666
						THEN
							SET phase = 2;
					ELSE
						SET phase = 3;
					END IF;

					CALL tool_getRandDatetime(@randDateTime, '2010-10-10 00:00:00', NOW());

					REPLACE INTO amr_device_path (DEVICE_CODE, CON_CODE, DEVICE_NUM, DEVICE_ADDRESS,
					                             PARENT_CODE, PARENT_NUM, PARENT_DEVICE_ADDRESS,
					                             LO, LA, DEVICE_SIGNAL, PHASE, RELATIVE_PHASE, READ_TIME)
						SELECT
							b.ID,
							@conNum,
							b.DEVICE_NUM,
							i,

							NULL,
							NULL,
							'louv',

							RAND() * 10 + 105,
							RAND() * 10 + 15,
							FLOOR(RAND() * 100),
							phase,
							'xx',
							@randDateTime
						FROM am_device AS b
						WHERE b.TYPE = '0' AND b.ID NOT IN (
							SELECT
								c.DEVICE_CODE
							FROM amr_device_path AS c
						)
						LIMIT 1;

					SET i = i + 1;

					IF i > itemAmount
					THEN
						LEAVE generate;
					END IF;

				END LOOP;
			END;

			-- 2. 更新父节点信息
			BEGIN
				DECLARE PDA VARCHAR(25);

				SELECT
					COUNT(*)
				INTO @amount
				FROM amr_device_path;

				SET i = 0;

				updateData: LOOP

					SELECT
						DEVICE_CODE
					INTO @parentCode
					FROM amr_device_path
					ORDER BY RAND()
					LIMIT 1;

					IF RAND() < 0.666
					THEN
						UPDATE amr_device_path AS a
							LEFT JOIN amr_device_path AS b ON b.DEVICE_CODE = @parentCode
							JOIN (
								     SELECT
									     d.DEVICE_CODE
								     FROM amr_device_path AS d
								     WHERE PARENT_DEVICE_ADDRESS = 'louv'
								     ORDER BY RAND()
								     LIMIT 1
							     ) AS c ON c.DEVICE_CODE = a.DEVICE_CODE
						SET
							a.PARENT_CODE           = b.DEVICE_CODE,
							a.PARENT_NUM            = b.DEVICE_NUM,
							a.PARENT_DEVICE_ADDRESS = b.DEVICE_ADDRESS;
					ELSE
						IF (RAND() < 0.6)
						THEN
							SET PDA = '0';
						ELSE
							SET PDA = 'BROKEN';
						END IF;

						UPDATE amr_device_path AS a
						SET
							a.PARENT_DEVICE_ADDRESS = PDA
						WHERE a.PARENT_DEVICE_ADDRESS = 'louv'
						LIMIT 1;
					END IF;

					SET i = i + 1;

					IF i > @amount
					THEN
						LEAVE updateData;
					END IF;

				END LOOP;

			END;

		END IF;
	END;

